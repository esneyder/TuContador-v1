
	<div class="row-fluid">
		<div class="span12">
			<a href="index.php" class="met_logo met_logo_loading"><img src="img/logo.png" height="44" alt="" /></a>
			<aside class="clearfix">
				<a href="http://www.facebook.com/" target="_blank" class="met_color3 met_color_transition"><i class="icon-facebook"></i></a>
				<a href="http://www.twitter.com/" target="_blank" class="met_color3 met_color_transition"><i class="icon-twitter"></i></a>
				<a href="https://plus.google.com/" target="_blank" class="met_color3 met_color_transition"><i class="icon-google-plus"></i></a>
				<a href="http://www.pinterest.com/" target="_blank" class="met_color3 met_color_transition"><i class="icon-pinterest"></i></a>
				<a href="#" class="met_color3 met_color_transition"><i class="icon-rss"></i></a>

				<nav>
					<ul>
						<li><a href="#" class="met_color_transition">Noticias</a></li>
						<li><a href="#" class="met_color_transition">FAQ</a></li>
						<li><a href="#" class="met_color_transition">Contacto</a></li>
					</ul>
				</nav>
			</aside>

			<div id="dl-menu" class="dl-menuwrapper">
				<button class="met_bgcolor met_bgcolor_transition2">MENU</button>
				<ul class="dl-menu met_bgcolor7">
					<li>
						<a href="index.php">Inicio</a>
					</li>
					<li><a href="about.html">Nosotros</a></li>
					 
					<li>
						<a href="#">Portafolio</a>
						<ul class="dl-submenu">
							<li class="dl-back"><a href="#">Atrás</a></li>
							 <li>
								<a href="#">Servicios</a>
								<ul class="dl-submenu">
									<li class="dl-back"><a href="#">Atrás</a></li>
									 <li><a href="#">Contable</a></li>
									<li><a href="#">Tributaria</a></li>
									<li><a href="#">Finanzas</a></li>
									<li><a href="#">Costos</a></li>
									<li><a href="#">Auditoria</a></li>				 
									<li><a href="#">Gerencia</a></li>
							
								</ul>
							</li>
							<li><a href="404.html">Hosting</a></li>
							<li><a href="search_results.html">Search Results</a></li>
							 
						</ul>
					</li>
					 
					 
					<li><a href="#">Blog</a></li>
					<li><a href="#">Clientes</a></li>
					<li><a href="#">Noticias</a></li>
					<li><a href="contact.html">Contatenos</a></li>
				</ul>
			</div><!-- /dl-menuwrapper -->

			
		</div>
	</div>
	<script src="js/modernizr.custom.65274.js"></script>

<!-- Scripts -->
	<script src="js/jquery.js"></script>

	<!--[if (gte IE 6)&(lte IE 8)]><script src="js/selectivizr-min.js"></script><![endif]-->
	<script src="js/retina.js"></script>
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<script src="js/bootstrap.js"></script>
	<script src="js/caroufredsel.js"></script>
	<script src="js/fullscreenr.js"></script>

	<script src="js/jquery.nouislider.min.js"></script>
	<script src="js/metcreative.html5audio.js"></script>

	<script src="http://maps.google.com/maps/api/js?sensor=true"></script>
	<script src="js/gmaps.js"></script>
	<script src="js/nicescroll.js"></script>
	<script src="js/jquery.dlmenu.js"></script>
	<script src="js/jquery.knob.js"></script>
	<script src="js/mobile_detector.js"></script>
	<script src="js/jquery.easing.js"></script>
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/custom.js"></script>
<footer class="met_bgcolor3 clearfix">
	<div class="met_content">
		<div class="row-fluid">
			<div class="span4">
				<h3 class="met_color2">PONERSE EN CONTACTO</h3>
				<span class="met_color2">Lorem ipsum dolor sit amet, consectetur adipisicing</span>
				<div class="met_footer_social_icons">
					<a class="met_color2 met_color_transition" target="_blank" href="http://www.facebook.com/"><i class="icon-facebook"></i></a>
					<a class="met_color2 met_color_transition" target="_blank" href="http://twitter.com/"><i class="icon-twitter"></i></a>
					<a class="met_color2 met_color_transition" target="_blank" href="http://www.pinterest.com/"><i class="icon-pinterest"></i></a>
					<a class="met_color2 met_color_transition" target="_blank" href="https://plus.google.com/"><i class="icon-google-plus"></i></a>
					<a class="met_color2 met_color_transition" href="#"><i class="icon-rss"></i></a>
				</div>
			</div>
			<div class="span8">
				<ul class="met_footer_menu">
					<li><a class="met_color2" href="index.php">Inicio</a></li>
					<li><a class="met_color2" href="#">Nosotros</a></li>
					<li><a class="met_color2" href="#">Portafolio</a></li>					 
					<li><a class="met_color2" href="#">Blog</a></li>
					<li><a class="met_color2" href="#">Clientes</a></li>
					<li><a class="met_color2" href="#">Noticias</a></li>
					<li><a class="met_color2" href="#">Contactenos</a></li>
				</ul>
				<select class="met_responsive_nav">
					<option value="index.php">Inicio</option>
					<option value="#">Nosotros</option>
					<option value="#">Portafolio</option>
					<option value="#">Blog</option>
					<option value="#">Clientes</option>
					<option value="#">Noticias</option>
					<option value="#">Contactenos</option>
				</select>
			</div>
		</div>
	</div>
	<div class="met_footer_copyright clearfix">
		<div class="met_content">
			<p class="met_color2">© 2015 AUDITORIAS Y CONSULTORIAS INTEGRALES S.A.S</p>
		</div>
	</div>
</footer>
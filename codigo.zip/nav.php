<ul>
		<li class="met_bgcolor_transition2"><a href="index.php" class="met_menu_home"><i class="icon-home"></i></a></li>
		<li class="met_bgcolor_transition2"><a href="about.html">Nosotros</a></li>		 
		<li class="met_bgcolor_transition2">
			<a href="#">Portafolio</a>
			<ul>
			<li class="met_has_lower">
						<a href="#">Servicios</a>
						<ul>
							 
							<li><a href="#">Contable</a></li>
							<li><a href="#">Tributaria</a></li>
							<li><a href="#">Finanzas</a></li>
							<li><a href="#">Costos</a></li>
							<li><a href="#">Auditoria</a></li>				 
							<li><a href="#">Gerencia</a></li>
						</ul>
					</li>
				<li><a href="#">Hosting</a></li>
				<li><a href="#">Diseño Web</a></li>
				 
				 
			</ul>
		</li>
		 
		 
		 <li class="met_bgcolor_transition2"><a href="#">Blog</a></li>
		 <li class="met_bgcolor_transition2"><a href="#">Clientes</a></li>
		 <li class="met_bgcolor_transition2"><a href="#">Noticias</a></li>
		<li class="met_bgcolor_transition2"><a href="contact.php">Contactenos</a></li>
	</ul>